choices = ["A","B"]
from time import sleep 
print "Hi I'm Bob I'm the captain of the space ship we are on. To do a choice you have to press a or b"
name= input("what was your name again?")
print "That's right! " + name + (" Welcome aboard")
sleep(3)
print "The space ship suddenly shakes"
sleep(2)
print "What was that?"
print ("You can:")
print ("Choice A: Say Nothing")
print ("Choice B: Run away")
choice1 = input("what do you do")#choice
if choice1 == "a" or choice1 == "A": 
  print "That doesn't sound like nothing!"
  sleep(2)
  print "Bob checks the computer screens."
  sleep(2)
  print("Bob: It looks like something has drilled a hole into the spaceship")
  sleep(2)
  print("You and Bob run out of the bridge and into the hallway.")
  sleep(3)
  print("You turn the corner and see a large alien with long legs and a big forehead at the head of the hall.")
  sleep(4)
  print("Turi: Don't worry captain I got this!")
  sleep(2)
  print("Turi runs towards the alien and starts shooting it.")
  sleep(2)
  print("Turi: Eat lead you big ugly alien!")
  sleep(2)
  print("Turi gets knocked over by the aliens legs, it leaps on him and stomps on his head.")
  print ("You can:")
  print ("Choice A: Cut off some of Turi's flesh")
  print ("Choice B: Run away")
  choice2a=input("What do you do?")#choice
  if choice2a == "a" or choice2a == "A":
    print ("You run towards Turi's body and cut off his flesh.")
    print ("Turi comes back to life and stabs you.")#die
  elif choice2a == "b" or choice2a == "B":
   print("You forget about Turi and Run away into the bridge")
   print ("You can:")
   print ("Choice A:Escape into the vent")
   print ("Choice B:Stay in the bridge ")
   choice22a=input("What do you do?")#choice
   if choice22a == "a" or choice22a == "A":
    print ("You escape into the vent where you end up in the basketball room where Clint is missing shots")
    print ("Clint:Hey guys!.")
    print ("Clint there's a alien on board!")
    print ("Bob:Turi is dead!")
    print ("Clint:I never liked him anyway.")
    print ("Olly runs into the room ")
    print ("Olly:I heard there's a alien on board")
    print ("Bob:We should find the dock")
    print ("You run to the dock.")
    print ("You find two different ships")
    print ("You can:")
    print ("Choice A:Take the crappy ship")
    print ("Choice B:Take the fancy ship ")
   choice22c=input("What do you do?")#choice
   if choice22c == "a" or choice22c == "A":
     print("You all get on the ship and manage to get the ship in space.")
     print("Olly:This ship sounds like it's going to explode.")
     print("In space there's a giant alien space ship")
     print ("Choice A:Hide on a nearby moon.")
     print ("Choice B:Hide on the alien ship. ")
     choice222a=input("What do you do?")#choice
   if choice222a == "a" or choice222a == "A":
     print("You park your ship on the moon.")
     print("A Alien worm comes out of a crater and eats you.")#die
   elif choice222a == "b" or choice222a == "B":   
     print("You manage to evade the ship and escape back to earth.")
     print("You sit on your couch and take a sip of potato juice.")
  elif choice22c == "b" or choice22c == "B": 
    print("You get on the ship and manage to get it into space")
    print("This ship doesn't sound like it's going to explode")
    print("The ship explodes")#die
  elif choice22a == "b" or choice22a == "B":
    print ("The alien leaps on you and kills you")#die
elif choice1 == "b" or choice1 == "B":
  print "(You run into a vent and hide)"
  print ("You can:")
  print ("Choice A: Go left")
  print ("Choice B: Go right")
  choice2b = input("What do you do?")#choice
  if choice2b == "A" or choice2b == "a":
    print ("You go left and see Bob Ross")
    print ("You try to crawl away but Bob Ross catches you and strangles you.")#die
  elif choice2b == "B" or choice2b == "b":
    print ("You go right and see Clint missing shots.")
    print ("Clint:Hey, new recruit.")
    print ("You see Bob come out of the vent on the other side of the room.")
    print ("Bob: Turis Dead, the alien got him.")
    print ("Clint:Alien?")
    print ("Bob: We need to find Olly, Where should we go.")
    print ("You ")
    print ("You can:")
    print ("Choice A: Bathroom ")
    print ("Choice B: Disco")
    choice2bb = input("What do you do?")#choice
    if choice2bb == "a" or choice2bb == "A":
      print ("You knock on the bathroom door")
      print ("The alien comes out and you die from the stench.")#die
    elif choice2bb == "b" or choice2bb == "B":
      print ("You find Olly dancing.")
      print ("Bob: Olly lets go!")
      print ("Olly: Why?")
      print ("Bob: Because there's a alien on board.")
      print ("You hear the toilet flush. You see the alien walk in the room.")
      print ("You can")
      print ("Choice A: Go into the secret hatch")
      print ("Choice B: Use clint as bait.")
      choice2bbb = input("What do you do?")#choice
      choice2bbb = choice2bbb.lower()
      if choice2bbb == "a": 
        print("You enter the hatch with everyone and walk through the tunnels ")
        print("You see a ladder and you all climb up it")
        print("You realise its the communication room")
        print("Clint:We can use the radio to contact another ship!")
        print("Bob grabs the radio, this is Bob Wardolf Bob we need help.")
        print("There's a ugly alien on our ship and it wants to kill us.")
        print("Dylan:This is Captain Dylan, we hear you, were going to help you ")
        print("Dylan: You will have to make it to the dock for us to pick you up.")
        print("Bob:Alright, we'll see you there.")
        print("You run to the dock")
        print("The ship lands but three aliens come out of the ship")
        print("Olly:The aliens tricked us.")
        print("Clint grabs a shot gun out of his pocket")
        print("Bob:You had that the whole time!")
        print("Clint shoots the aliens.")
        print("Bob:Everyone get to the ship.")
        print("You all run to the ship.")
        print("Clint:There's a grenade in the ship.")
        print("Clint throws the grenade at the aliens, killing them.")
        print("The original alien comes out of nowhere.")
        print("It jumps on Bob.")
        print ("You can")
        print ("Choice A: Save Bob")
        print ("Choice B: Leave him.")
        choice2bbbba = input("What do you do?")#choice
        choice2bbbba = choice2bbbba.lower()
        if choice2bbbba == "a":
          print("You punch the alien saving Bob.")
          print("The alien bites you.")
          print("You run towards the ship,closing the door just in time.")
          print("Olly:You okay")
          print ("You can")
          print ("Choice A: No I got bit")
          print ("Choice B: I'm fine.")
          choice2bbbbaa = input("What do you do?")#choice
          choice2bbbbaa = choice2bbbbaa.lower()
          if choice2bbbbaa == "a":
           print("Bob:I'm sorry little one.")
           print("Clint points his gun at you and shoots")#die
        elif choice2bbbbaa == "b":
            print("Olly:Okay then")
            print("Olly:Since this is a alien ship we will be diguised from the aliens.")
            print("Clint drives the ship back to earth")
            print("You arrive on earth.")
            print("You come out of the ship and see the military pointing guns at you.")
            print("Finn:They are aliens shoot them.")
            print("You feel weird and turn into a alien")
            print("You attack the military and take over earth")
            print("Alien ending")#die
            
        elif choice2bbbba == "b":
          print("You run to the ship.")
          print("Bob punches the alien but gets bit")
          print("Bob gets on the ship and the door closes in time")
          print("Bob:I got bit")
          print ("You can")
          print ("Choice A: Tell Clint to shoot him")
          print ("Choice B: Let him live.")
        choice2bbbbba = input("What do you do?")#choice
        choice2bbbbba = choice2bbbbba.lower()
        if choice2bbbbba == "a":
          print("Clint shoots him")
          print("Clint:sometimes the hardest choices require the strongest wills")
          print("Olly:Since this is a alien ship we will be diguised from the aliens.")
          print("Clint drives the ship back to earth")
          print("You arrive on earth.")
          print("You come out of the ship and see the military pointing guns at you.")
          print("Finn:They are aliens shoot them.")
          print("They shoot and kill you.")#die
      elif choice2bbbbba == "b": 
          print("You let him live")
          print("")
          print("Olly:Since this is a alien ship we will be diguised from the aliens.")
          print("Clint drives the ship back to earth")
          print("You arrive on earth.")
          print("You come out of the ship and see the military pointing guns at you.")
          print("Finn:They are aliens shoot them.")
          print("Bob turns into a alien and attacks the military")
          print("You go back into the ship and escape.")
          print("You find a desert planet for you and the crew to live on")
          print("Run aways ending")#die
      elif choice2bbb == "b": 
          print ("You push Clint towards the alien and run into the secret hatch.")
          print ("You Bob and Olly climb down the ladder and walk through the tunnels ")
          print ("You see Clint appear in front of you with a shot gun ")
          print ("Choice A: Sacrifice Olly ")
          print ("Choice B: Sacrifice Bob.")
      choice2bbbc = input("What do you do?")#choice
      choice2bbbc= choice2bbb.lower()
      if choice2bbbc == "a": 
        print("You push Olly in front of you and he gets shot.")
        print("You run away with Bob and climb up a ladder. ")
        print ("Bob slips")
        print ("Bob hits his head on floor and dies")
        print ("You climb up and see Clint")
        print ("You wake up in Hell")#die
    elif choice2bbbc == "b": 
        print("You push Bob in front of you and he gets shot")
        print("You run away with olly and climb up a ladder. ")
        print("Olly slips")
        print("Olly hits his head on the floor and die")
        print("You climb and see Clint")
        print ("You wake up in Hell")
        print ("Evil ending")#die
        
else:
  print ("The universe explodes because you can't type a or b in.")#die
   